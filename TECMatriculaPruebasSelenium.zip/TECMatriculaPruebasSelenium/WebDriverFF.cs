﻿using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace TestingJquerySelenium
{
   public class WebDriverFF:WebDriver
    {
        public WebDriverFF()
        {
            FirefoxProfile profile = new FirefoxProfile(@"C:\DRIVERS\geckodriver.exe");
         driver = new FirefoxDriver(profile);
        }
    }
}
