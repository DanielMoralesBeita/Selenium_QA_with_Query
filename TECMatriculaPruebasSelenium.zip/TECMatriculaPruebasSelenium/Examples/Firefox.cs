using NUnit.Framework;
using System;

using System.Web;
using System.Text;
using System.Net;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Drawing.Imaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading;

namespace TestingJquerySelenium
{ //TODO configuraci�n usuarios y respuesta. 
    [TestFixture()]
    [TestClass]
    public class Sprint1Firefox:WebDriverFF{
        String Carpeta = @"FF\Fotos_14092016\";
        String CarpetaRaiz = @"C:\Screenshots\";
        WebDriverFucTest WebAux = new WebDriverFucTest();
        [SetUp]
        public void Init() {
         
        }

     /// <summary>
     /// Sirve para configurar las rutas si se quiere utilizar otra ruta para la toma de fotos!!.
     /// </summary>
        public void Inicializar()
        {

            driver.Navigate().GoToUrl("http://develomentmaster.com/");
            WebAux.banderarutaAlterna = true;
        }
        public void IrUrl(String URLDestino)
        {
            driver.Navigate().GoToUrl(URLDestino);
      
        }
        public void InicioSesion(int[] width, int[] height, string Usuario, string email, string tel, string message)
        {
            IrUrl("http://develomentmaster.com#contact");
            WebAux.driver = driver;
            WebAux.banderarutaAlterna = true;
            String Ruta = WebAux.CrearDirectorioYDevolverRuta(@"C:\Screenshots\Firefox", "InicioSesion" + WebAux.LimpiarFormatoFecha());
  
            WebAux.AddVal("#name", Usuario);
            Thread.Sleep(1000);
            WebAux.InicioFotos(driver, Ruta, width, height);
            WebAux.AddVal("#email", email);
            Thread.Sleep(1000);
            WebAux.InicioFotos(driver, Ruta, width, height);
            WebAux.AddVal("#message", message);
            Thread.Sleep(1000);
            WebAux.InicioFotos(driver, Ruta, width, height);
            WebAux.AddVal("#phone", tel);
            Thread.Sleep(1000);
            WebAux.InicioFotos(driver, Ruta, width, height);
            WebAux.Click("button.btn.btn-xl");
            Thread.Sleep(1000);

            Thread.Sleep(10000);
            WebAux.InicioFotos(driver, Ruta, width, height);

        }
        public bool ComprobarElementoVisible(string selector)
        {
          return  WebAux.ExcuteBool("$(\""+selector+ "\").is(\":visible\");");
        }
        public string ComprobarElementostring(string selector)
        {
            return WebAux.Excutestring("$(\"" + selector + "\").text();");
        }

 
        IWebElement clicke;
    
        [TestMethod]
        [Test]
        public void CP_001_Iniciodesesion()
        {
            //Suma Cantidad de la ventana del navegador en el alto
            int alto = 94;
            int[] height = { 640 + alto, 640 + alto, 640 + alto, 640 + alto, 640 + alto };
            //Suma Cantidad de la ventana del navegador en el ancho
            int ancho = 14;
            int[] width = { 992 + ancho, 991 + ancho, 769 + ancho, 768 + ancho, 360 + ancho };


            
           //Casos de prueba
            InicioSesion(width, height, "1", "1","1","1");
            InicioSesion(width, height, "1", " ", "1", "1");
            InicioSesion(width, height, "1", "1", " ", "1");
            InicioSesion(width, height, "1", "1", "1", " ");
            InicioSesion(width, height, " ", "1", "1", "1");
            InicioSesion(width, height, " ", " ", "1", "1");
            InicioSesion(width, height, " ", " ", " ", "1");
            InicioSesion(width, height, " ", " ", " ", " ");
            InicioSesion(width, height, "1", "1", " ", " ");
            InicioSesion(width, height, "1", " ", " ", " ");
            InicioSesion(width, height, "1", " ", " ", "1");
            InicioSesion(width, height, "1", " ", "1", "1");
            driver.Quit();
        }
      

        [TearDown]
        public void Cleanup() {
            driver.Quit();
        }
    }
}
